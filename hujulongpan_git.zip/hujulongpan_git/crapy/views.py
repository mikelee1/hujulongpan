from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.auth import user_logged_in
# Create your views here.


def index(request):
    context={
        'request':request

    }
    return render(request, "index.html")

def login(request):
    return render(request,'login.html')

def register(request):
    return render(request,'register.html')


def detailinfo(request,infoid):
    context={
        'infoid':infoid
    }
    return render(request, 'detailinfo.html',context)

@login_required(login_url='crapy:login')
def personalcenter(request):

    return render(request,'personalcenter.html')

@login_required(login_url='crapy:login')
def mycollector(request):
    return render(request,'mycollector.html')