function  getTable(json) {
    $('#careerTable').bootstrapTable('destroy');

    var col = ['发布时间','标题'];
    var dataOriginal= json.response_data;

    //columns序列
    var columns = new  Array();
    for( a in col){
        dic = {field:col[a],title:col[a]};
        columns.push(dic);
    }

    //data序列
    var data = new  Array;
    for (a in dataOriginal){
        pagetime = dataOriginal[a].pagetime;
        pageTitle = dataOriginal[a].title;
        var item = {"发布时间":pagetime,'标题':pageTitle};
        data.push(item);
    }

    //bootstrapTable建表格
     $('#careerTable').bootstrapTable({
        classes: 'table-no-bordered',
        data:data,
        columns: columns
    });
     $('#careerTable').bootstrapTable('hideLoading');
}
