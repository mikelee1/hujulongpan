from django.conf.urls import url

from . import views

app_name = 'crapy'
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^login/$', views.login, name='login'),
    url(r'^register/$', views.register, name='register'),
    url(r'^detailinfo/(?P<infoid>[0-9]+)/$', views.detailinfo, name='detailinfo'),
    url(r'^personalcenter/$', views.personalcenter, name='personalcenter'),
    url(r'^mycollector/$', views.mycollector, name='mycollector')

]
