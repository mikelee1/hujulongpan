from django.shortcuts import render
from django.contrib.auth.decorators import login_required,user_passes_test
from rest_framework.decorators import permission_classes
from rest_framework import permissions
# Create your views here.

# def test(user):
#     return user.is_authenticated() and user.has_perm("polls.can_vote")
#
# #@login_required(login_url='crapy:login')
# @user_passes_test(test,login_url='crapy:login')
# @permission_classes((permissions.IsAdminUser,))
def home(request):
    return render(request,'home.html')
