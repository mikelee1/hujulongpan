from django.conf.urls import url

from . import views
app_name='admin_console'
urlpatterns = [
    url(r'^$', views.home, name='home'),

]