from . import views
from django.conf.urls import url
app_name = 'rest_server'
urlpatterns = [
    url(r'^getCareer/$', views.getCareer, name='getCareer'),
    url(r'^showCareerInfo/$',views.showCareerInfo,name='showCareerInfo'),
    url(r'^register/$',views.register,name='register'),
    url(r'^login/$',views.login,name='login'),
    url(r'^logout/$',views.logout,name='logout'),
    url(r'^detail/$',views.detail,name='detail'),
    url(r'^resumesubmit/$', views.resumesubmit, name='resumesubmit'),
    url(r'^collect/$',views.collect,name='collect'),
    url(r'^collectortable/$',views.collectortable,name='collectortable'),
    url(r'^changename/$',views.changename,name='changename')
]