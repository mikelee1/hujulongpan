# -*- coding: cp936 -*-
import re
import urllib
import chardet
from rest_server.models import *
from django.shortcuts import render
from rest_framework import response, status, permissions
from . import constants
from django.contrib.auth import login as django_login, authenticate, logout as django_logout
from django.contrib.auth.decorators import login_required
from validators import Validator
from serializers import SubmitRecordRestSerializer
from rest_framework.decorators import api_view, permission_classes
import calendar
from serializers import CollectorSerializer

# Create your views here.
@api_view(['GET', 'post'])
@permission_classes((permissions.AllowAny,))
def getCareer(request):
    id = request.POST['id']
    try:
        res = startCrapy(id)
        currid = res.pop()
        return response.Response(constants.to_response_withpageid(res, currid), status=status.HTTP_200_OK)
    except:
        return response.Response(constants.ILLEGAL_REQUEST_PARAMETERS, status=status.HTTP_200_OK)


def getHtml(url):
    page = urllib.urlopen(url)
    html = page.read()
    return html


# ����ҳ��ȡ������Ϣ
def getRegInfo(html, reg):
    imgre = re.compile(reg)
    reglist = re.findall(imgre, html)
    return reglist


def VerifyEncode(page):
    bianma = chardet.detect(page)['encoding']
    if bianma == 'GB2312':
        page = page.decode('gb2312', 'ignore').encode('utf-8')
    return page


def startCrapy(id):
    infoToHtml = []
    if id:
        html = getHtml('http://bbs.seu.edu.cn/bbsdoc.php?board=jobs&ftype=6&page=' + id + '')
    else:
        html = getHtml('http://bbs.seu.edu.cn/bbsdoc.php?board=jobs&ftype=6')

    html = VerifyEncode(html)

    ids1 = getRegInfo(html, reg=r'c\.o.*?,(.+?),')
    currentid = int(getRegInfo(html, reg=r'docWriter.*?\'.*?\',.*?,.*?,.*?,.*?,(.*?),')[0])
    ids = set(ids1)
    for pageId in ids:
        if CareerInfo.objects.filter(idinfo=pageId).exists():
            print ('%s has already exited' % pageId)
            infoToHtml.append({'pagetime': CareerInfo.objects.get(idinfo=pageId).pagetime,
                               'title': CareerInfo.objects.get(idinfo=pageId).title})
            continue
        detailPage = getHtml("http://bbs.seu.edu.cn/bbscon.php?bid=96&id=" + pageId + "")
        # ����ת��
        detailPage = VerifyEncode(detailPage)

        detailInfo = getRegInfo(detailPage, reg=r'prints.*jobs\\n.*?:(.*?)\\n.*?SBBS(.*?),.*?\\n\\n(.*?)--.*;')
        detailInfo = list(detailInfo[0])
        infoToHtml.append({'pagetime': timesplit(detailInfo[1]), 'title': detailInfo[0]})
        detailInfo[2]=detailInfo[2].strip().replace('\\n', ' ')
        writeIntoMysql(detailInfo, pageId)
        print ("finish write %s" % pageId)

    infoToHtml.append(currentid)
    return infoToHtml


def writeIntoMysql(detailInfo, pageId):
    infoObject = CareerInfo.objects.create(
        idinfo=pageId,
        title=detailInfo[0],
        pagetime=timesplit(detailInfo[1]),
        content=detailInfo[2]
    )
    infoObject.save()


monthtonum = {num: key for key, num in enumerate(calendar.month_abbr)}


def timesplit(s):
    a = s.strip().strip('(').strip(')').split()
    a[0] = a.pop()
    a[1] = str(monthtonum[a[1]])
    return '-'.join(a[:3]) + ' ' + a[3]


@api_view(['get'])
@permission_classes((permissions.AllowAny,))
def showCareerInfo(request):
    queryset = CareerInfo.objects.all().order_by('-pagetime')
    return list_view(request, queryset, SubmitRecordRestSerializer)


def list_view(request, queryset, serializer):
    validator = Validator(request.query_params)
    validator.validate('offset', required=True, isdigit=True, min=0)
    validator.validate('limit', required=True, isdigit=True, min=0)
    if not validator.is_valid:
        return response.Response(constants.ILLEGAL_REQUEST_PARAMETERS, status=status.HTTP_200_OK)

    offset = int(request.query_params['offset'])
    limit = int(request.query_params['limit'])

    total = len(queryset)
    queryset = queryset[offset:offset + limit]

    rows = [serializer(row).data for row in queryset]

    return response.Response({'total': total, 'rows': rows}, status=status.HTTP_200_OK)


@api_view(['post'])
@permission_classes((permissions.AllowAny,))
def register(request):
    name = request.POST['username']
    password = request.POST['password']
    # User.objects.get(username=name)

    User.objects.create(username=name)
    user = User.objects.get(username=name)
    user.set_password(password)
    user.save()
    return response.Response(constants.to_response('success'))


@api_view(['post'])
@permission_classes((permissions.AllowAny,))
def login(request):
    validator = Validator(request.POST)
    validator.username()
    validator.validate('password', required=True, min_length=6)
    if not validator.is_valid:
        return response.Response(constants.ILLEGAL_REQUEST_PARAMETERS, status=status.HTTP_200_OK)
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(username=username, password=password)
    if user is None:
        print 'user is none'
        return response.Response(constants.USER_NOT_EXIST_OR_WRONG_PASSWORD)
    else:
        id = User.objects.get(username=username).id
        print user
        django_login(request, user)
        return response.Response(constants.to_response(id))


@api_view(['get'])
def logout(request):
    django_logout(request)
    return response.Response(constants.DEFAULT, status=status.HTTP_200_OK)


@api_view(['post', 'get'])
@permission_classes((permissions.AllowAny,))
def detail(request):
    if request.method == 'POST':
        career_id = request.POST['career_id']
        careerinfo = CareerInfo.objects.filter(id=career_id)
        return response.Response(constants.to_response(careerinfo[0].content))


@api_view(['post'])
@login_required(login_url='crapy:login')
def resumesubmit(request):
    user = User.objects.get(id=request.user.id)
    if 'resume' in request.FILES:
        if Userextension.objects.filter(user=user).exists():
            u = Userextension.objects.get(user=user)
        else:
            u = Userextension.objects.create(user=user)
            u.save()
        u.resume = request.FILES['resume']
        u.save()
    return response.Response(constants.to_response(user.username))


@api_view(['post'])
@login_required(login_url='crapy:login')
def collect(request):
    lis = []
    user = User.objects.filter(id=request.user.id)[0]
    for j in request.POST:
        lis.append(request.POST[j])

    for i in lis:
        carinfo = CareerInfo.objects.filter(id=i)  # must use filter for iteration in line 1
        if Usercol.objects.filter(user=user, collection=carinfo[0]).exists():
            continue
        Usercol.objects.create(user=user, collection=carinfo[0])
        # use.collection=carinfo  #line 1
    return response.Response(constants.to_response('nice'))


@api_view(['post', 'get'])
def collectortable(request):
    user = User.objects.get(id=request.user.id)
    queryset = Usercol.objects.filter(user=user)

    offset = int(request.query_params['offset'])
    limit = int(request.query_params['limit'])

    total = len(queryset)
    queryset = queryset[offset:offset + limit]

    rows = [CollectorSerializer(row).data for row in queryset]

    return response.Response({'total': total, 'rows': rows}, status=status.HTTP_200_OK)

@api_view(['post', 'get'])
def changename(request):
    user=User.objects.get(id=request.user.id)
    user.username=request.POST['newname']
    user.save()
    return response.Response(constants.to_response('nice'))
