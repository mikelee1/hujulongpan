from __future__ import unicode_literals

from django.apps import AppConfig


class RestServerConfig(AppConfig):
    name = 'rest_server'
