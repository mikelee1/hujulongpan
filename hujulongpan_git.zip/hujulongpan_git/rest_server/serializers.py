from rest_framework import serializers
from models import CareerInfo, Usercol


class SubmitRecordRestSerializer(serializers.ModelSerializer):
    idinfo = serializers.SerializerMethodField()
    title = serializers.SerializerMethodField()

    class Meta:
        model = CareerInfo
        exclude = ('content',)

    def get_idinfo(self, obj):
        return obj.idinfo

    def get_title(self, obj):
        return obj.title


class CollectorSerializer(serializers.ModelSerializer):
    # this queryset only contains usercol's id, user, and collection at first, and title should be added extraly.
    title = serializers.SerializerMethodField()

    # collector = serializers.SerializerMethodField()
    # this model contains the first infomations
    class Meta:
        model = Usercol

    def get_title(self, obj):
        return obj.collection.title
