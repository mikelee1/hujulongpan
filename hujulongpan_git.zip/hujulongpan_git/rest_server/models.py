from __future__ import unicode_literals

from django.db import models
from django.utils import timezone

from django.contrib.auth.models import User, Group, Permission


# Create your models here.
class CareerInfo(models.Model):
    idinfo = models.IntegerField()
    title = models.CharField(max_length=128)
    time = models.DateTimeField(default=timezone.now)
    pagetime = models.DateTimeField(default=timezone.now)
    content = models.TextField()


class Userextension(models.Model):
    user = models.OneToOneField(User)
    resume = models.FileField(upload_to='resume', default=None)


class Usercol(models.Model):
    user = models.ForeignKey(User)
    # collection=models.ManyToManyField(CareerInfo)
    collection = models.ForeignKey(CareerInfo)

    def __str__(self):
        return self.user.username


class Cpinfo(models.Model):
    cpname = models.CharField(max_length=128)
    cphone = models.CharField(max_length=128)
    create_time = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.cpname


class Cpuser(models.Model):
    uname = models.CharField(max_length=128)
    sex = models.CharField(max_length=100)

    def __str__(self):
        return self.uname


class Teacher(models.Model):
    name = models.CharField(max_length=128)
    marry = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Course(models.Model):
    course_id = models.IntegerField(null=True)
    course_name = models.CharField(max_length=100, null=True)

    def __str__(self):
        return self.course_name


class Student(models.Model):
    name = models.CharField(max_length=100)
    sex = models.CharField(max_length=100, default='male')
    birthday = models.DateTimeField(default=timezone.now)

    num = models.IntegerField(null=True)

    # teacher = models.ManyToManyField(Teacher, related_name='mystudent')


    def __str__(self):
        return 'name:%s,sex:%s' % (self.name, self.sex)


class CST(models.Model):
    teacher = models.ForeignKey(Teacher, null=True, related_name='course')
    course = models.ForeignKey(Course, null=True, related_name='stu_tea')
    student = models.ForeignKey(Student, null=True, related_name='stucourse')

    def __str__(self):
        return 'course:%s teacher:%s student:%s' % (self.course.course_name, self.teacher.name, self.student.name)
